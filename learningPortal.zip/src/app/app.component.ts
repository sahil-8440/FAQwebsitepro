import { Component } from '@angular/core';
import {QA} from "../assets/json/questionAnswers";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  public selectedCat = 'All';

  public title = 'learningPortal';

  public questionAnswers = QA;

  public categories: string[] = [];

  constructor(){}

  ngOnInit(){
    for (let entry of this.questionAnswers) {
      if(this.categories.includes(entry.cat) !== true){
        this.categories.push(entry.cat);
      }
    }
  }

  getAllQuestions(){
    this.selectedCat = 'All';
    this.questionAnswers = QA;
  }

  getSpecficCategoryQuestions(cat:any){
    this.selectedCat = cat;
    this.questionAnswers = QA.filter( i => i.cat === cat);
  }
 
}
