export const QA = [
    {
        id: '0001',
        question: 'General some question',
        answer: 'some ans',
        cat: 'General'
    },
    {
        id: '0002',
        question: 'General some question',
        answer: 'some ans',
        cat: 'General'
    },
    {
        id: '0003',
        question: 'UI some question',
        answer: 'some ans',
        cat: 'UI'
    },
    {
        id: '0004',
        question: 'UI some question',
        answer: 'some ans',
        cat: 'UI'
    },
    {
        id: '0005',
        question: 'Angular some question',
        answer: 'some ans',
        cat: 'Angular'
    },
    {
        id: '0006',
        question: 'Angular some question',
        answer: 'some ans <strong>test</span>',
        cat: 'Angular'
    },
    {
        id: '0007',
        question: 'some question',
        answer: 'some ans',
        cat: 'Java'
    },
    {
        id: '0008',
        question: 'some question',
        answer: 'some ans',
        cat: 'Java'
    }
];