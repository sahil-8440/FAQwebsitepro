import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FaqComponent } from './faq/faq.component';
import { LoginComponent } from './login/login.component';



const routes: Routes = [
  /* {path: '', pathMatch: 'full', redirectTo: 'faq'},
  {path: 'login' , component: LoginComponent},
  {path: 'faq' , component: FaqComponent},
  {path: '**', component: FaqComponent} */
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
