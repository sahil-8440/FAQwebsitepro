import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {QA} from "../../assets/json/questionAnswers";
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FaqComponent implements OnInit {

  public url = 'assets/json/quesAns.json' 
  public selectedCat = 'All';
  public questionAnswers:any;

  public categories: string[] = [];
  public allquestionAnswers: any;

  constructor(private httpClient: HttpClient){}

  ngOnInit(){
    this.getQA().subscribe((res) => {
      this.allquestionAnswers = this.questionAnswers = res;
      for (let entry of this.questionAnswers) {
        if(this.categories.includes(entry.cat) !== true){
          this.categories.push(entry.cat);
        }
      }
    });
  }

  getAllQuestions(){
    this.selectedCat = 'All';
    this.getQA().subscribe((res) => {
      this.questionAnswers = res;
    });
  }

  getSpecficCategoryQuestions(cat:any){
    this.selectedCat = cat;
    this.questionAnswers = this.allquestionAnswers.filter( (i: { cat: any; }) => i.cat === cat);
  }



  public getQA(){   
    return this.httpClient.get(this.url);
  }

}
